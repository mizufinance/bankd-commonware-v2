/* tslint:disable */
/* eslint-disable */

export class ForwardingAddrResponse {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * A noble address that will be used for registration on the noble network
     */
    noble_addr_bech32: string;
    /**
     * Byte representation of the noble forwarding address. Used for broadcasting cosmos message.
     */
    noble_addr_bytes: Uint8Array;
    /**
     * The shieldd address that a deposit to the noble address with forward to
     * Vec encoded `pb::Address`
     */
    shieldd_addr_bytes: Uint8Array;
}

export class TransparentAddrResponse {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * The raw (binary) transparent address
     */
    address: Uint8Array;
    /**
     * The t-address encoding of the transparent address
     */
    encoding: string;
}

export class TxpAndTxvBytes {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    txp: Uint8Array;
    txv: Uint8Array;
}

export class ViewServer {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Get new notes and SCT state updates.
     * Function also clears state
     * Returns: `ScanBlockResult`
     */
    flush_updates(): any;
    /**
     * Reconstructs the state commitment tree (SCT) from the full genesis block using
     * the genesis advice.
     */
    genesis_advice(full_compact_block: Uint8Array): Promise<boolean>;
    /**
     * SCT root can be compared with the root obtained by GRPC and verify that there is no divergence
     * Returns: `Uint8Array representing a Root`
     */
    get_sct_root(): Uint8Array;
    /**
     * Checks if address is controlled by view server full viewing key
     */
    is_controlled_address(address: Uint8Array): boolean;
    /**
     * Create new instances of `ViewServer`
     * Function opens a connection to indexedDb
     * Arguments:
     *     full_viewing_key: `byte representation inner FullViewingKey`
     *     epoch_duration: `u64`
     *     stored_tree: `StoredTree`
     *     idb_constants: `IndexedDbConstants`
     * Returns: `ViewServer`
     */
    static new(full_viewing_key: Uint8Array, stored_tree: any, idb_constants: any): Promise<ViewServer>;
    /**
     * Create new instances of `ViewServer` from SCT frontier snapshot.
     */
    static new_snapshot(full_viewing_key: Uint8Array, idb_constants: any, compact_frontier: Uint8Array): Promise<ViewServer>;
    /**
     * Scans block for notes.
     * Returns true if the block contains new notes or false if the block is empty for us.
     *     compact_block: `v1::CompactBlock`
     * Scan results are saved in-memory rather than returned
     * Use `flush_updates()` to get the scan results
     * Returns: `bool`
     */
    scan_block(compact_block: Uint8Array, skip_trial_decrypt: boolean): Promise<boolean>;
    /**
     * Scans a chunk of the genesis block for notes that can be trial decrypted with the viewing key.
     */
    scan_genesis_chunk(start: bigint, partial_compact_block: Uint8Array, skip_trial_decrypt: boolean): Promise<void>;
}

/**
 * Authorize transaction using a spend key.
 */
export function authorize(spend_key: Uint8Array, transaction_plan: Uint8Array): Uint8Array;

/**
 * Deprecated browser entrypoint retained as a hard error so stale consumers do
 * not silently fall back to host-only proof generation.
 */
export function build_action(_transaction_plan: Uint8Array, _action_plan: Uint8Array, _full_viewing_key: Uint8Array, _witness_data: Uint8Array): Uint8Array;

/**
 * Builds the witness payload required by the local HTTP prover for the
 * requested action. This is intentionally binary-only across the WASM
 * boundary; ActionPlan JSON is not accepted or produced.
 */
export function build_action_proof_request(transaction_plan: Uint8Array, action_plan: Uint8Array, full_viewing_key: Uint8Array, witness_data: Uint8Array): any;

/**
 * Builds a binary Action from a binary ActionPlan and a packed gnark proof
 * result returned by the local HTTP prover.
 */
export function build_action_with_proof_result(transaction_plan: Uint8Array, action_plan: Uint8Array, full_viewing_key: Uint8Array, witness_data: Uint8Array, proof_result: Uint8Array): Uint8Array;

/**
 * Build a transaction from binary Actions, a binary TransactionPlan, binary
 * WitnessData, and binary AuthorizationData. No Action or ActionPlan JSON is
 * accepted at this boundary.
 */
export function build_parallel(actions: any, transaction_plan: Uint8Array, witness_data: Uint8Array, auth_data: Uint8Array): Uint8Array;

/**
 * Deprecated browser entrypoint retained as a hard error so stale consumers do
 * not use host-only transaction proving in WASM.
 */
export function build_serial(_full_viewing_key: Uint8Array, _transaction_plan: Uint8Array, _witness_data: Uint8Array, _auth_data: Uint8Array): Uint8Array;

/**
 * Given a binary-encoded `Metadata`, returns a new binary-encoded `Metadata`
 * with the symbol customized if the token is one of several specific types
 * that don't have built-in symbols.
 */
export function customize_symbol(metadata_bytes: Uint8Array): Uint8Array;

/**
 * Heights and transaction bytes must come from the verifier's chosen node, independently of the package.
 */
export function disclosure_confirm_acceptance(_package: string, chain_id: string, committed_blocks: string): string;

export function disclosure_export(witness: string, method: string): string;

export function disclosure_inspect(_package: string): string;

/**
 * Returns private witness JSON. Keep it local; it is not a shareable disclosure.
 */
export function disclosure_prepare(request: string, committed_transactions: string, full_viewing_key: Uint8Array): string;

/**
 * Cryptographic validity only. Acceptance remains NotChecked until independently confirmed.
 */
export function disclosure_verify(_package: string): string;

/**
 * generate a spend key from a seed phrase
 * Arguments:
 *     seed_phrase: `string`
 * Returns: `Uint8Array representing inner SpendKey`
 */
export function generate_spend_key(seed_phrase: string): Uint8Array;

/**
 * get address by index using FVK
 * Arguments:
 *     full_viewing_key: `byte representation inner FullViewingKey`
 *     account: `u32`
 *     randomizer: `12 bytes, with 0 bytes representing all 0s implicitly`
 * Returns: `Uint8Array representing inner Address`
 */
export function get_address_by_index(full_viewing_key: Uint8Array, account: number, randomizer: Uint8Array): Uint8Array;

/**
 * generate the appropriate AssetId for a binary-serialized protobuf
 * `AssetId` potentially containing an `altBaseDenom` or `altBech32m` string
 * field
 *
 * Arguments:
 *     input_id_bin: `Uint8Array` representing a binary-serialized `AssetId`
 *
 * Returns:
 *     `Uint8Array` representing a binary-serialized `AssetId`
 */
export function get_asset_id(input_id_bin: Uint8Array): Uint8Array;

/**
 * get ephemeral (randomizer) address using FVK
 * The derivation tree is like "spend key / address index / ephemeral address" so we must also pass index as an argument
 * Arguments:
 *     full_viewing_key: `byte representation inner FullViewingKey`
 *     index: `u32`
 * Returns: `Uint8Array representing inner Address`
 */
export function get_ephemeral_address(full_viewing_key: Uint8Array, index: number): Uint8Array;

/**
 * get full viewing key from spend key
 * Arguments:
 *     spend_key: `byte representation inner SpendKey`
 * Returns: `Uint8Array representing inner FullViewingKey`
 */
export function get_full_viewing_key(spend_key: Uint8Array): Uint8Array;

/**
 * Returns the AddressIndex of an address.
 * If it is not controlled by the FVK, it returns a `None`
 * Arguments:
 *     full_viewing_key: `byte representation inner FullViewingKey`
 *     address: `byte representation inner Address`
 * Returns: `Option<AddressIndex>`
 */
export function get_index_by_address(full_viewing_key: Uint8Array, address: Uint8Array): any;

/**
 * Generates an address that can be used as a forwarding address for Noble
 * Returns: Uint8Array representing encoded Address
 */
export function get_noble_forwarding_addr(sequence: number, full_viewing_key: Uint8Array, channel: string, account?: number | null): ForwardingAddrResponse;

/**
 * get transmission key (public key for this payment address)
 * Arguments:
 *     address: `byte representation inner Address`
 * Returns: `Uint8Array representing inner Address`
 */
export function get_transmission_key_by_address(address: Uint8Array): Uint8Array;

/**
 * Returns the "truncated" address (t-addr) associated with the account.
 */
export function get_transparent_address(full_viewing_key: Uint8Array): TransparentAddrResponse;

/**
 * Wallet id: the hash of a full viewing key, used as an account identifier
 * Arguments:
 *     full_viewing_key: `byte representation inner FullViewingKey`
 * Returns: `WalletId`
 */
export function get_wallet_id(full_viewing_key: Uint8Array): Uint8Array;

/**
 * Checks if address is controlled by full viewing key provided
 */
export function is_controlled_address(full_viewing_key: Uint8Array, address: Uint8Array): boolean;

export function plan_transaction(idb_constants: any, request: Uint8Array, full_viewing_key: Uint8Array, _gas_fee_token: Uint8Array, grpc_url: string): Promise<Uint8Array>;

export function prepare_orbis_packages(plan: Uint8Array, transaction: Uint8Array, delivery: string): string;

export function sct_position(block_height: bigint, epoch_bytes: Uint8Array): bigint;

export function transaction_perspective_and_view(_full_viewing_key: Uint8Array, _tx: Uint8Array, _idb_constants: any): Promise<TxpAndTxvBytes>;

export function transaction_summary(_txv: Uint8Array): Promise<Uint8Array>;

/**
 * Validate issued evidence; registrar allowlists and current state remain enforced at chain admission.
 */
export function validateAssetRegistration(message: Uint8Array, chain_id: string, current_unix: bigint): Uint8Array;

export function validateUserRegistration(message: Uint8Array, policy_bytes: Uint8Array, chain_id: string, current_unix: bigint): Uint8Array;

/**
 * Build witness data from a transaction plan and serialized IndexedDB SCT.
 */
export function witness(transaction_plan: Uint8Array, stored_tree: any): Uint8Array;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_forwardingaddrresponse_free: (a: number, b: number) => void;
    readonly __wbg_get_forwardingaddrresponse_noble_addr_bech32: (a: number) => [number, number];
    readonly __wbg_get_forwardingaddrresponse_noble_addr_bytes: (a: number) => [number, number];
    readonly __wbg_get_forwardingaddrresponse_shieldd_addr_bytes: (a: number) => [number, number];
    readonly __wbg_get_transparentaddrresponse_address: (a: number) => [number, number];
    readonly __wbg_get_transparentaddrresponse_encoding: (a: number) => [number, number];
    readonly __wbg_get_txpandtxvbytes_txp: (a: number) => [number, number];
    readonly __wbg_get_txpandtxvbytes_txv: (a: number) => [number, number];
    readonly __wbg_set_forwardingaddrresponse_noble_addr_bech32: (a: number, b: number, c: number) => void;
    readonly __wbg_set_forwardingaddrresponse_noble_addr_bytes: (a: number, b: number, c: number) => void;
    readonly __wbg_set_forwardingaddrresponse_shieldd_addr_bytes: (a: number, b: number, c: number) => void;
    readonly __wbg_set_transparentaddrresponse_address: (a: number, b: number, c: number) => void;
    readonly __wbg_set_transparentaddrresponse_encoding: (a: number, b: number, c: number) => void;
    readonly __wbg_set_txpandtxvbytes_txp: (a: number, b: number, c: number) => void;
    readonly __wbg_set_txpandtxvbytes_txv: (a: number, b: number, c: number) => void;
    readonly __wbg_transparentaddrresponse_free: (a: number, b: number) => void;
    readonly __wbg_txpandtxvbytes_free: (a: number, b: number) => void;
    readonly __wbg_viewserver_free: (a: number, b: number) => void;
    readonly authorize: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly build_action: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number, number, number];
    readonly build_action_proof_request: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number, number];
    readonly build_action_with_proof_result: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number) => [number, number, number, number];
    readonly build_parallel: (a: any, b: number, c: number, d: number, e: number, f: number, g: number) => [number, number, number, number];
    readonly build_serial: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number, number, number];
    readonly customize_symbol: (a: number, b: number) => [number, number, number, number];
    readonly disclosure_confirm_acceptance: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
    readonly disclosure_export: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly disclosure_inspect: (a: number, b: number) => [number, number, number, number];
    readonly disclosure_prepare: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
    readonly disclosure_verify: (a: number, b: number) => [number, number, number, number];
    readonly generate_spend_key: (a: number, b: number) => [number, number, number, number];
    readonly get_address_by_index: (a: number, b: number, c: number, d: number, e: number) => [number, number, number, number];
    readonly get_asset_id: (a: number, b: number) => [number, number, number, number];
    readonly get_ephemeral_address: (a: number, b: number, c: number) => [number, number, number, number];
    readonly get_full_viewing_key: (a: number, b: number) => [number, number, number, number];
    readonly get_index_by_address: (a: number, b: number, c: number, d: number) => [number, number, number];
    readonly get_noble_forwarding_addr: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number];
    readonly get_transmission_key_by_address: (a: number, b: number) => [number, number, number, number];
    readonly get_transparent_address: (a: number, b: number) => [number, number, number];
    readonly get_wallet_id: (a: number, b: number) => [number, number, number, number];
    readonly is_controlled_address: (a: number, b: number, c: number, d: number) => [number, number, number];
    readonly plan_transaction: (a: any, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number) => any;
    readonly prepare_orbis_packages: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
    readonly sct_position: (a: bigint, b: number, c: number) => [bigint, number, number];
    readonly transaction_perspective_and_view: (a: number, b: number, c: number, d: number, e: any) => any;
    readonly transaction_summary: (a: number, b: number) => any;
    readonly validateAssetRegistration: (a: number, b: number, c: number, d: number, e: bigint) => [number, number, number, number];
    readonly validateUserRegistration: (a: number, b: number, c: number, d: number, e: number, f: number, g: bigint) => [number, number, number, number];
    readonly viewserver_flush_updates: (a: number) => [number, number, number];
    readonly viewserver_genesis_advice: (a: number, b: number, c: number) => any;
    readonly viewserver_get_sct_root: (a: number) => [number, number, number, number];
    readonly viewserver_is_controlled_address: (a: number, b: number, c: number) => [number, number, number];
    readonly viewserver_new: (a: number, b: number, c: any, d: any) => any;
    readonly viewserver_new_snapshot: (a: number, b: number, c: any, d: number, e: number) => any;
    readonly viewserver_scan_block: (a: number, b: number, c: number, d: number) => any;
    readonly viewserver_scan_genesis_chunk: (a: number, b: bigint, c: number, d: number, e: number) => any;
    readonly witness: (a: number, b: number, c: any) => [number, number, number, number];
    readonly wasm_bindgen__convert__closures_____invoke__h03a9273bb60a7433: (a: number, b: number, c: any) => [number, number];
    readonly wasm_bindgen__convert__closures_____invoke__h47f9c719264a6244: (a: number, b: number, c: any, d: any) => void;
    readonly wasm_bindgen__convert__closures_____invoke__h203ebb7d03cbad97: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen__convert__closures_____invoke__hde85efc72056abaf: (a: number, b: number) => number;
    readonly wasm_bindgen__convert__closures_____invoke__h90a02760d481ece0: (a: number, b: number) => void;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_destroy_closure: (a: number, b: number) => void;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
